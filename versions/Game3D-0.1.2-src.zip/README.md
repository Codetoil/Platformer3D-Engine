# Game3D

Game3D, a 3D Platformer built for the web. It is currently in elementary stages. Version 0.1.2
